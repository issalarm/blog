const express = require('express');
const router = express.Router();
const { subscribe, unsubscribe, isSubscribed } = require('../models/Subscription');

// Подписаться на пользователя
router.post('/subscribe/:userId', (req, res) => {
  const user = req.session.user;
  if (!user) {
    return res.status(401).send('Вы должны быть авторизованы.');
  }

  const targetId = parseInt(req.params.userId, 10);
  if (isNaN(targetId)) {
    return res.status(400).send('Неверный ID пользователя.');
  }

  subscribe(user.id, targetId, (err, subscriptionId) => {
    if (err) return res.status(500).send('Ошибка подписки.');
    res.redirect(`/profile/${targetId}`);
  });
});

// Отписаться от пользователя
router.post('/unsubscribe/:userId', (req, res) => {
  const user = req.session.user;
  if (!user) {
    return res.status(401).send('Вы должны быть авторизованы.');
  }

  const targetId = parseInt(req.params.userId, 10);
  if (isNaN(targetId)) {
    return res.status(400).send('Неверный ID пользователя.');
  }

  unsubscribe(user.id, targetId, (err, success) => {
    if (err) return res.status(500).send('Ошибка отписки.');
    if (!success) return res.status(400).send('Вы не подписаны на этого пользователя.');
    res.redirect(`/profile/${targetId}`);
  });
});

module.exports = router;