const express = require('express');
const router = express.Router();
const { createPost, getAllPosts, getPublicPosts, getPostById, updatePost, deletePost } = require('../models/Post');
const { getAllTags, linkTagsToPost } = require('../models/Tag'); // Импортируем linkTagsToPost
const { addComment, getCommentsByPostId } = require('../models/Comment');

// Главная страница (GET)
router.get('/', (req, res) => {
  const user = req.session.user;

  getAllPosts((err, posts) => {
    if (err) return res.status(500).send('Ошибка загрузки постов.');

    getAllTags((err, tags) => {
      if (err) return res.status(500).send('Ошибка загрузки тегов.');

      res.render('index', { user, posts: posts || [], tags: tags || [] });
    });
  });
});

// Страница создания поста (GET)
router.get('/create', (req, res) => {
  const user = req.session.user;
  if (!user) return res.redirect('/login');

  // Получаем все теги
  getAllTags((err, tags) => {
    if (err) return res.status(500).send('Ошибка загрузки тегов.');
    res.render('create-post', { tags: tags || [] });
  });
});

// Обработка формы создания поста (POST)
router.post('/create', (req, res) => {
  const user = req.session.user;
  if (!user) return res.redirect('/login');

  const { title, content, isPublic, tags } = req.body;
  const tagList = Array.isArray(tags) ? tags : [tags];

  createPost(title, content, user.id, isPublic === 'on', tagList, (err, postId) => {
    if (err) return res.status(500).send('Ошибка создания поста.');
    res.redirect('/');
  });
});

// Страница редактирования поста (GET)
router.get('/edit/:postId', (req, res) => {
  const postId = parseInt(req.params.postId, 10);
  if (isNaN(postId)) return res.status(400).send('Неверный ID поста.');

  const user = req.session.user;
  if (!user) return res.redirect('/login');

  // Получаем пост по ID
  getPostById(postId, (err, post) => {
    if (err) return res.status(500).send('Ошибка загрузки поста.');
    if (!post || post.author_id !== user.id) return res.status(403).send('Доступ запрещен.');

    getAllTags((err, tags) => {
      if (err) return res.status(500).send('Ошибка загрузки тегов.');

      res.render('edit-post', { post, tags: tags || [] });
    });
  });
});

// Обработка формы редактирования поста (POST)
router.post('/edit/:postId', (req, res) => {
  const postId = parseInt(req.params.postId, 10);
  if (isNaN(postId)) return res.status(400).send('Неверный ID поста.');

  const user = req.session.user;
  if (!user) return res.redirect('/login');

  const { title, content, isPublic, tags } = req.body;
  const tagList = Array.isArray(tags) ? tags : [tags];

  // Обновляем пост
  updatePost(postId, title, content, isPublic === 'on', (err, updated) => {
    if (err) return res.status(500).send('Ошибка обновления поста.');
    if (!updated) return res.status(404).send('Пост не найден или доступ запрещен.');

    // Привязываем теги к посту
    linkTagsToPost(postId, tagList, (err) => {
      if (err) return res.status(500).send('Ошибка связывания тегов.');
      res.redirect('/');
    });
  });
});

// Удаление поста (POST)
router.post('/delete/:postId', (req, res) => {
  const postId = parseInt(req.params.postId, 10);
  if (isNaN(postId)) return res.status(400).send('Неверный ID поста.');

  const user = req.session.user;
  if (!user) return res.redirect('/login');

  // Удаляем пост
  deletePost(postId, (err, deleted) => {
    if (err) return res.status(500).send('Ошибка удаления поста.');
    if (!deleted) return res.status(404).send('Пост не найден или доступ запрещен.');
    res.redirect('/');
  });
});

module.exports = router;