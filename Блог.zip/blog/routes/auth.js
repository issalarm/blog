const express = require('express');
const router = express.Router();
const { createUser, findUserByEmail } = require('../models/User');
const bcrypt = require('bcryptjs');

// Страница регистрации (GET)
router.get('/register', (req, res) => {
  res.render('register');
});

// Обработка формы регистрации (POST)
router.post('/register', (req, res) => {
  const { username, email, password } = req.body;

  findUserByEmail(email, (err, user) => {
    if (err) return res.status(500).send('Ошибка сервера.');
    if (user) return res.status(400).send('Пользователь с таким email уже существует.');

    createUser(username, email, password, (err, userId) => {
      if (err) return res.status(500).send('Ошибка регистрации.');
      res.redirect('/login');
    });
  });
});

// Страница входа (GET)
router.get('/login', (req, res) => {
  res.render('login');
});

// Обработка формы входа (POST)
router.post('/login', (req, res) => {
  const { email, password } = req.body;

  findUserByEmail(email, (err, user) => {
    if (err) return res.status(500).send('Ошибка сервера.');
    if (!user) return res.status(400).send('Неверный email или пароль.');

    const isMatch = bcrypt.compareSync(password, user.password);
    if (!isMatch) return res.status(400).send('Неверный email или пароль.');

    req.session.user = user;
    res.redirect('/');
  });
});

// Маршрут для выхода
router.get('/logout', (req, res) => {
  req.session.destroy((err) => {
    if (err) return res.status(500).send('Ошибка при выходе.');
    res.redirect('/');
  });
});

module.exports = router;