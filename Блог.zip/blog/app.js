const express = require('express');
const session = require('express-session');
const path = require('path');
const { getAllPosts } = require('./models/Post');
const { findUserById, getAllUsers } = require('./models/User'); // Добавляем импорт getAllUsers
const { isSubscribed } = require('./models/Subscription');
const app = express();

app.use(express.static(path.join(__dirname, 'public')));

// Настройка EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use(
  session({
    secret: 'secret-key',
    resave: false,
    saveUninitialized: true,
  })
);

// Маршруты
const authRoutes = require('./routes/auth');
const postsRoutes = require('./routes/posts');
const subscriptionsRoutes = require('./routes/subscriptions');
app.use('/', authRoutes);
app.use('/posts', postsRoutes);
app.use('/subscriptions', subscriptionsRoutes);

// Главная страница
app.get('/', (req, res) => {
  const user = req.session.user;

  // Получаем все посты
  getAllPosts((err, posts) => {
    if (err) return res.status(500).send('Ошибка загрузки постов.');

    // Получаем всех пользователей
    getAllUsers((err, users) => {
      if (err) return res.status(500).send('Ошибка загрузки пользователей.');

      res.render('index', { 
        user: user || null, // Убедитесь, что user всегда определен
        posts: posts || [], // Убедитесь, что posts всегда массив
        users: users || []  // Убедитесь, что users всегда массив
      });
    });
  });
});

// Профиль пользователя
app.get('/profile/:userId', (req, res) => {
  const user = req.session.user;
  const profileUserId = parseInt(req.params.userId, 10);

  if (isNaN(profileUserId)) {
    return res.status(400).send('Неверный ID пользователя.');
  }

  findUserById(profileUserId, (err, profileUser) => {
    if (err) return res.status(500).send('Ошибка загрузки профиля.');
    if (!profileUser) return res.status(404).send('Пользователь не найден.');

    if (user && user.id !== profileUser.id) {
      isSubscribed(user.id, profileUser.id, (err, subscribed) => {
        if (err) return res.status(500).send('Ошибка проверки подписки.');
        res.render('profile', { user, profileUser, isSubscribed: subscribed });
      });
    } else {
      res.render('profile', { user, profileUser, isSubscribed: false });
    }
  });
});

// Запуск сервера
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});