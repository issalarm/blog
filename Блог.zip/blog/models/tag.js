const sqlite3 = require('sqlite3').verbose();

// Подключение к базе данных
const db = new sqlite3.Database('./database.db');

// Создание таблиц для тегов
db.serialize(() => {
  db.run(`
    CREATE TABLE IF NOT EXISTS tags (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS post_tags (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      post_id INTEGER NOT NULL,
      tag_id INTEGER NOT NULL,
      FOREIGN KEY (post_id) REFERENCES posts (id),
      FOREIGN KEY (tag_id) REFERENCES tags (id)
    )
  `);
});

// Функция для добавления тега
function addTag(name, callback) {
  db.run('INSERT OR IGNORE INTO tags (name) VALUES (?)', [name], function (err) {
    if (err) return callback(err);
    callback(null, this.lastID); // Возвращаем ID нового тега
  });
}

// Функция для получения всех тегов
function getAllTags(callback) {
  db.all('SELECT * FROM tags', [], (err, rows) => {
    if (err) return callback(err);
    callback(null, rows || []);
  });
}

// Функция для связывания тегов с постом
function linkTagsToPost(postId, tagNames, callback) {
  const tagPromises = tagNames.map((tagName) => {
    return new Promise((resolve, reject) => {
      addTag(tagName, (err, tagId) => {
        if (err) return reject(err);
        resolve(tagId);
      });
    });
  });

  Promise.all(tagPromises)
    .then((tagIds) => {
      const insertPromises = tagIds.map((tagId) => {
        return new Promise((resolve, reject) => {
          db.run(
            'INSERT INTO post_tags (post_id, tag_id) VALUES (?, ?)',
            [postId, tagId],
            (err) => {
              if (err) return reject(err);
              resolve();
            }
          );
        });
      });
      return Promise.all(insertPromises);
    })
    .then(() => callback(null))
    .catch((err) => callback(err));
}

module.exports = {
  addTag,
  getAllTags,
  linkTagsToPost,
};