const sqlite3 = require('sqlite3').verbose();

// Подключение к базе данных
const db = new sqlite3.Database('./database.db');

// Создание таблицы для подписок
db.serialize(() => {
  db.run(`
    CREATE TABLE IF NOT EXISTS subscriptions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      subscriber_id INTEGER NOT NULL,
      target_id INTEGER NOT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (subscriber_id) REFERENCES users (id),
      FOREIGN KEY (target_id) REFERENCES users (id)
    )
  `);
});

// Функция для подписки на пользователя
function subscribe(subscriberId, targetId, callback) {
  db.run(
    'INSERT INTO subscriptions (subscriber_id, target_id) VALUES (?, ?)',
    [subscriberId, targetId],
    function (err) {
      if (err) return callback(err);
      callback(null, this.lastID); // Возвращаем ID новой подписки
    }
  );
}

// Функция для отписки от пользователя
function unsubscribe(subscriberId, targetId, callback) {
  db.run(
    'DELETE FROM subscriptions WHERE subscriber_id = ? AND target_id = ?',
    [subscriberId, targetId],
    function (err) {
      if (err) return callback(err);
      callback(null, this.changes > 0); // Возвращаем true, если подписка удалена
    }
  );
}

// Функция для проверки подписки
function isSubscribed(subscriberId, targetId, callback) {
  db.get(
    'SELECT * FROM subscriptions WHERE subscriber_id = ? AND target_id = ?',
    [subscriberId, targetId],
    (err, row) => {
      if (err) return callback(err);
      callback(null, !!row); // Возвращаем true, если подписка существует
    }
  );
}

module.exports = {
  subscribe,
  unsubscribe,
  isSubscribed,
};