const sqlite3 = require('sqlite3').verbose();
const { linkTagsToPost } = require('./Tag');

// Подключение к базе данных
const db = new sqlite3.Database('./database.db');

// Создание таблицы для постов
db.serialize(() => {
  db.run(`
    CREATE TABLE IF NOT EXISTS posts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      content TEXT NOT NULL,
      author_id INTEGER NOT NULL,
      is_public BOOLEAN DEFAULT 1, -- 1 = публичный, 0 = приватный
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (author_id) REFERENCES users (id)
    )
  `);
});

// Функция для создания нового поста
function createPost(title, content, authorId, isPublic, tags, callback) {
  if (!callback || typeof callback !== 'function') {
    throw new Error('Callback is required and must be a function.');
  }

  db.run(
    'INSERT INTO posts (title, content, author_id, is_public) VALUES (?, ?, ?, ?)',
    [title, content, authorId, isPublic],
    function (err) {
      if (err) {
        console.error('Ошибка при добавлении поста в базу данных:', err); // Логируем ошибку
        return callback(err);
      }

      const postId = this.lastID;

      // Привязываем теги к посту
      linkTagsToPost(postId, tags, (err) => {
        if (err) {
          console.error('Ошибка при связывании тегов:', err); // Логируем ошибку
          return callback(err);
        }
        callback(null, postId);
      });
    }
  );
}

// Функция для получения всех постов
function getAllPosts(callback) {
  if (!callback || typeof callback !== 'function') {
    throw new Error('Callback is required and must be a function.');
  }

  db.all('SELECT * FROM posts ORDER BY created_at DESC', [], (err, rows) => {
    if (err) return callback(err);
    callback(null, rows || []);
  });
}

// Функция для получения публичных постов
function getPublicPosts(callback) {
  if (!callback || typeof callback !== 'function') {
    throw new Error('Callback is required and must be a function.');
  }

  db.all('SELECT * FROM posts WHERE is_public = 1 ORDER BY created_at DESC', [], (err, rows) => {
    if (err) return callback(err);
    callback(null, rows || []);
  });
}

// Функция для получения поста по ID
function getPostById(postId, callback) {
  if (!callback || typeof callback !== 'function') {
    throw new Error('Callback is required and must be a function.');
  }

  db.get('SELECT * FROM posts WHERE id = ?', [postId], (err, row) => {
    if (err) return callback(err);
    callback(null, row);
  });
}

// Функция для обновления поста
function updatePost(postId, title, content, isPublic, callback) {
  if (!callback || typeof callback !== 'function') {
    throw new Error('Callback is required and must be a function.');
  }

  db.run(
    'UPDATE posts SET title = ?, content = ?, is_public = ? WHERE id = ?',
    [title, content, isPublic, postId],
    function (err) {
      if (err) return callback(err);
      callback(null, this.changes > 0); // Возвращаем true, если пост обновлен
    }
  );
}

// Функция для удаления поста
function deletePost(postId, callback) {
  if (!callback || typeof callback !== 'function') {
    throw new Error('Callback is required and must be a function.');
  }

  db.run('DELETE FROM posts WHERE id = ?', [postId], function (err) {
    if (err) return callback(err);
    callback(null, this.changes > 0); // Возвращаем true, если пост удален
  });
}

module.exports = {
  createPost,
  getAllPosts,
  getPublicPosts,
  getPostById,
  updatePost,
  deletePost,
};