const sqlite3 = require('sqlite3').verbose();

// Подключение к базе данных
const db = new sqlite3.Database('./database.db');

// Создание таблицы для комментариев
db.serialize(() => {
  db.run(`
    CREATE TABLE IF NOT EXISTS comments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      post_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      content TEXT NOT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (post_id) REFERENCES posts (id),
      FOREIGN KEY (user_id) REFERENCES users (id)
    )
  `);
});

// Функция для добавления комментария
function addComment(postId, userId, content, callback) {
  db.run(
    'INSERT INTO comments (post_id, user_id, content) VALUES (?, ?, ?)',
    [postId, userId, content],
    function (err) {
      if (err) return callback(err);
      callback(null, this.lastID); // Возвращаем ID нового комментария
    }
  );
}

// Функция для получения всех комментариев к посту
function getCommentsByPostId(postId, callback) {
  db.all(
    'SELECT comments.*, users.username FROM comments JOIN users ON comments.user_id = users.id WHERE post_id = ? ORDER BY created_at ASC',
    [postId],
    (err, rows) => {
      if (err) return callback(err);
      callback(null, rows || []);
    }
  );
}

module.exports = {
  addComment,
  getCommentsByPostId,
};