document.addEventListener('DOMContentLoaded', () => {
  console.log('Скрипт загружен!');
});